<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Andy Car service booking</title>
    </head>
    <body>
        <h1> Andy's car Servicing Company </h1>

        <br><br>
        <h3>Booking Details</h3> 

	<form>
		<!-- Enter your html form elements -->

        	<input type ="submit" value ="Book">
        </form>
    </body>
</html>
