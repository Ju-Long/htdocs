<?php
$host = "localhost";
$username = "root";
$password = "";
$db = "AndyCarServiceDB";
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
            // put your code here
        ?>
    </body>
</html>
